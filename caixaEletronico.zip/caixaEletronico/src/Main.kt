import java.awt.DefaultFocusTraversalPolicy

    var valorEscolha = 0
    var qtdDinheiro = 0.0
    var qtdDeposito = 0.0
    var qtdSaque = 0.0

fun main() {

    while (valorEscolha != 4) {

        println("[=======================]")
        println("===O que deseja fazer?===")
        println("[=======================]")
        println("1 - Consultar")
        println("2 - Depósito")
        println("3 - Saque")
        println("4 - Sair")
        println("[=======================]")

        valorEscolha = readln().toInt()

        if (valorEscolha == 1) {
            Consulta()
        }

        if (valorEscolha == 2) {
            Deposito()
        }

        if (valorEscolha == 3) {
            Saque()
        }

        if (valorEscolha == 4) {
            print("Você saiu.")
        }

    }
}

fun Consulta(){
    println("Você possui R$ $qtdDinheiro")
}

fun Deposito(){
    println("Quanto deseja depositar?")
    qtdDeposito = readln().toDouble()

    qtdDinheiro = qtdDinheiro + qtdDeposito
}

fun Saque(){
    println("Quanto deseja sacar?")
    qtdSaque = readln().toDouble()

    if(qtdSaque <= qtdDinheiro){
        qtdDinheiro = qtdDinheiro - qtdSaque
    }
    else {
        println("Você não possui dinheiro o suficiente")
    }
}